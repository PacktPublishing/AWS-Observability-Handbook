#!/bin/bash
set -eo pipefail
./bin/test-api.sh
