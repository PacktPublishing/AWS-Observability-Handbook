@Controller class JsApp { }
