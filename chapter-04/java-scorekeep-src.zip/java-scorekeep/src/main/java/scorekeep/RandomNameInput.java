package scorekeep;

public class RandomNameInput {
  private String category;
  private String userid;

  public String getCategory() { return category; }
  public void setCategory(String value) { category = value; }

  public String getUserid() { return userid; }
  public void setUserid(String value) { userid = value; }
}
